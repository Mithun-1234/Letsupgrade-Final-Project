C =int(input("Enter the Clesius value:"))
F = C*9/5 +32
print("The Farenheit value is:",F)